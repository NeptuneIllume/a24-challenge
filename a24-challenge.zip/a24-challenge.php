<?php
/**
 * @wordpress-plugin
 * Plugin Name:       A24 Challenge for Wordpress
 */

defined( 'ABSPATH' ) or die( 'Direct script access disallowed.' );

define( 'A24_WIDGET_PATH', plugin_dir_path( __FILE__ ) . '/widget' );
define( 'A24_ASSET_MANIFEST', A24_WIDGET_PATH . '/build/asset-manifest.json' );
define( 'A24_INCLUDES', plugin_dir_path( __FILE__ ) . '/includes' );

require_once( A24_INCLUDES . '/enqueue.php' );
require_once( A24_INCLUDES . '/shortcode.php' );